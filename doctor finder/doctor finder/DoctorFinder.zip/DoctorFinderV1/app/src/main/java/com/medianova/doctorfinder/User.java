package com.medianova.doctorfinder;

/**
 * Created by Redixbit on 24-08-2016.
 */
class User {
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    private String status;
}
