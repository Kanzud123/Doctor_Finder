package com.medianova.utils;

/**
 * Created by Redixbit 2 on 27-08-2016.
 */
public class bookapointmentgetset {

    private String status;
    private String Massage;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMassage() {
        return Massage;
    }

    public void setMassage(String massage) {
        Massage = massage;
    }
}
